<?php	
error_reporting(E_ALL^E_NOTICE^E_WARNING);
session_start();
if (isset($_SESSION['valid_user'])){
?>
You are logged in as : <?=$_SESSION['valid_user']?> <br/><br/> 
<a href="index.php?add">Add Comments</a><br/>
<?php
//add comment to database
if(isset($_GET['add'])){
?>
<form method="post" action="comment.php">
  <label for="comment">comment</label><br/>
  <textarea name="comment" id="comment" cols="45" rows="5"></textarea><br/>
   <input name="" type="submit" />
</form>
<?php
}//end add comment to database
else{
	/*
	In addition, the user should be able to specify the date/time range for query retrieval and all of the queries 
that fall into the specified time period should be displayed on the screen
*/?>
<form action="index.php?range=b" method="post">
<label>specify the date/time range The formats(2014-04-11 15:48:01)</label><br/>
  Strat Date Time: <input name="startdate" type="text" id="startdate" value="2014-04-11 15:48:01" /><br/>
  End Date Time: <input name="enddate" type="text" id="enddate" value="2014-04-21 15:48:01" /><br/>
  <input name="" type="submit" /><br/>
 <a href="index.php?range=a">List All Comments</a>  
</form>
<?php
//if the range value = a show all comments, if it's b user have set the range
if(isset($_GET['range'])){
	$ranges =0;
	$rangee=0;
	$range=$_GET['range'];
	if($range!='a')
{
		$ranges =$_POST['startdate'];
		$rangee =$_POST['enddate'];
//check the datetime input formats and if is valid
$format = 'Y-m-d H:i:s';
if(!(date($format, strtotime($ranges)) == $ranges)) {
$range = 'a';
$rangeError='start datetime wrong';
}
if(!(date($format, strtotime($rangee)) == $rangee)){
$range = 'a';
$rangeError='end datetime wrong';
}
if(isset($rangeError)) echo $rangeError."<br/><br/>";// output the error message
}
?>
<!--
The user must also be able to sort all displayed  records by their date/time fields in both ascendingand 
descending order
-->
<a href="<?php
if($range=='a') echo 'index.php?range=a&list=a';
else echo "index.php?range=b&list=ra&ranges=$ranges&rangee=$rangee"?>">List Comments by ascending order</a> |  
<a href="<?php
if($range=='a') echo 'index.php?range=a&list=d';
else echo "index.php?range=b&list=rd&ranges=$ranges&rangee=$rangee"?>">List Comments by descending order</a> |
<a href="control.php?logout=ture">Logout</a>
<?php

if(isset($_GET['list'])){
	$url = 'a';
	if(($_GET['list'])=='a') $order = 'ASC';
	if(($_GET['list'])=='d') $order = 'DESC';
	$username = $_SESSION['valid_user'];
	$con = mysql_connect("localhost", "webUser", "acm1234");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  $db_selected = mysql_select_db("webUser",$con);
  if((($_GET['list'])=='a')||(($_GET['list'])=='d'))
  {
		$query = "select * from comment "
				."where username='$username' "
				." ORDER BY  `comment`.`datetime` "
				.$order;
  }
  //user set the datetime range
  else{
	if(($_GET['list'])=='ra') $order = 'ASC';
	if(($_GET['list'])=='rd') $order = 'DESC';
	$ranges=$_GET['ranges'];
	$rangee=$_GET['rangee'];
	  $query = "select * from comment "
				."where username='$username' "
				."and datetime "
				."BETWEEN '$ranges' AND '$rangee' "
				."ORDER BY datetime "
				.$order;
	  }

				$result = mysql_query($query,$con);
		$url=$_GET['list'];
		/*
		Through a simple menu, the user should be able tochoose a particular date/time format to be displayed 
along with their comment.
*/
		echo "<br/>date/time format: <a href=\"index.php?range=$range&list=$url&format=1&ranges=$ranges&rangee=$rangee\">(Y-M-d H:i:s)</a> | <a href=\"index.php?range=$range&list=$url&format=2&ranges=$ranges&rangee=$rangee\">(Y-F-d H:i:s)</a> | <a href=\"index.php?range=$range&list=$url&format=3&ranges=$ranges&rangee=$rangee\">(m-d-y h:i:s A)</a>";
		$format = "Y-m-d H:i:s";
		/*
		The  date/time  information  must  be  displayable  in  at  least  three  different  formats  when  comments  are 
shown back to the user
		*/
		if(isset($_GET['format'])){
			if(($_GET['format'])=='1') $format = "Y-M-d H:i:s";
			if(($_GET['format'])=='2') $format = "Y-F-d H:i:s";
			if(($_GET['format'])=='3') $format = "m-d-y h:i:s A";
		}
		echo "<hr/>";
		while ($row = mysql_fetch_assoc($result)) { 
       echo "<br/>Name: ".$row['username']."<br/>Comment: ".$row['comment']."<br/>Date Time: ".date($format,strtotime($row['datetime']));
		echo "<hr/><br/>"; 
    } 

}
}
}
}
else{
?>
Login
<form action="control.php" method="post">
  <label for="username">username</label>
  <input name="username" type="text" id="username" value="authuser" /><br/>
  <label for="password">password</label>
  <input name="password" type="password" id="password" value="acm12" /><br/>
  <input name="" type="submit" />
</form>
<?php
}?>