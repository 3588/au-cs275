This directory is for cs275 assignment 7

2 new files /ajax

modify  2 files /page